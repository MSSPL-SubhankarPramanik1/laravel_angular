-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 31, 2015 at 11:46 PM
-- Server version: 5.5.46-0ubuntu0.14.04.2
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `laravel_angular`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_name_unique` (`name`),
  UNIQUE KEY `employees_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `contact_number`, `position`, `created_at`, `updated_at`) VALUES
(1, 'Bimal Pramanik', 'bimal.pramanik@gmail.com', '9434433430', 'Business Owner', '2015-12-23 12:35:32', '2015-12-24 13:43:10'),
(2, 'Subhankar Pramanik', 'subhankar.bachchu@gmail.com', '9474551165', 'TL', '2015-12-24 00:49:18', '2015-12-24 00:49:18'),
(3, 'Sunanda Ghosh', 'sunandaghosh.geo@gmail.com', '9474550177', 'AT', '2015-12-24 04:03:27', '2015-12-24 04:03:27'),
(4, 'Yuvraj Pratap Singh', 'yuvraj.singh@gmail.com', '9875465251', 'TL', '2015-12-24 13:06:56', '2015-12-24 13:07:10'),
(5, 'Susanta Pramanik', 'raju.susanta@gmail.com', '9434311924', 'Business Owner', '2015-12-24 13:42:37', '2015-12-24 13:42:56');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
